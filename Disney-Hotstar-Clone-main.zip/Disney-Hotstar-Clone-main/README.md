# Disney-Hotstar-Clone
In this video, we're going to show you how to clone the popular streaming service Disney+ using nothing but HTML, CSS, and JavaScript. We'll show you how to create the interface, how to populate it with content, and how to add some basic functionality. This is a great project for anyone who wants to learn how to create a web application from scratch. So if you're ready to get started, watch this video and learn how to clone Disney+!

We will use the following technologies:

- Html
- CSS
- Javascript

## Preview
![Disney+ Hotstar clone](https://user-images.githubusercontent.com/59678435/196937651-e83fff0a-cbad-4c6e-b930-50c6bb10d7a8.png)
